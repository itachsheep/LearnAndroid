# A live wallpaper project for Android
<a href="https://play.google.com/store/apps/details?id=com.kinglloy.album" target="_blank">
<img src="https://play.google.com/intl/en_us/badges/images/generic/en-play-badge.png" alt="Get it on Google Play" height="90"/></a>


# live-wallpaper
A live wallpaper demo - use GLWallpaperService

<img src="https://github.com/jinkg/Screenshots/blob/master/live-wallpaper/wallpaper_demo3.gif" width="180" height="320">
