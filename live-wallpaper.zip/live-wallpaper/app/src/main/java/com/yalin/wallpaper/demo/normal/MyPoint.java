package com.yalin.wallpaper.demo.normal;

/**
 * @author jinyalin
 * @since 2017/7/24.
 */

public class MyPoint {
    String text;
    int x;
    int y;

    public MyPoint(String text, int x, int y) {
        this.text = text;
        this.x = x;
        this.y = y;
    }
}
